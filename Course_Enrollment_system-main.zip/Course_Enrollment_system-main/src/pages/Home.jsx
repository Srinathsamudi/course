import React from "react";
import { Link } from "react-router-dom";
import "../style/Home.css"; // We'll create a separate CSS file
import {Navigate } from "react-router-dom";

export default function Home() {
  // Mock data for popular courses - in real app, this would come from API
  const popularCourses = [
    {
      id: 1,
      title: "React for Beginners",
      description: "Master the fundamentals of React and build modern web applications",
      duration: "6 weeks",
      level: "Beginner",
      rating: 4.8,
      students: 1250,
      instructor: "Sarah Johnson",
      price: "$89.99"
    },
    {
      id: 2,
      title: "Python Full Stack Development",
      description: "Learn backend + frontend development with Python, Django and React",
      duration: "10 weeks",
      level: "Intermediate",
      rating: 4.7,
      students: 890,
      instructor: "Mike Chen",
      price: "$129.99"
    },
    {
      id: 3,
      title: "Complete Web Development Bootcamp",
      description: "Master HTML, CSS, JavaScript and modern frameworks",
      duration: "12 weeks",
      level: "Beginner",
      rating: 4.9,
      students: 2100,
      instructor: "Emily Davis",
      price: "$149.99"
    }
  ];

  const features = [
    {
      icon: "🎯",
      title: "Expert-Led Courses",
      description: "Learn from industry professionals with real-world experience"
    },
    {
      icon: "⚡",
      title: "Learn at Your Pace",
      description: "Lifetime access to course materials and self-paced learning"
    },
    {
      icon: "📱",
      title: "Anywhere, Anytime",
      description: "Access courses on any device with our mobile-friendly platform"
    },
    {
      icon: "🎓",
      title: "Get Certified",
      description: "Earn certificates to showcase your skills to employers"
    }
  ];

  return (
    <div className="home-container">

      {/* HEADER */}
      {/* HEADER */}
      <header className="header">
        <div className="container">
          <div className="header-content">
            <div className="logo">
              <h1>LearnHub</h1>
            </div>

            <nav className="nav">
              <ul>
                <li><Link to="/Home" className="nav-link active">Home</Link></li>
                <li><Link to="/courselisting" className="nav-link">Courses</Link></li>
                <li><Link to="/admin" className="nav-link">Admin</Link></li>
              </ul>
            </nav>

            {/* 🔥 REPLACED LOGIN + SIGN UP WITH LOGOUT BUTTON */}
            <div className="header-actions">
              <Link to="/" className="btn btn-secondary btn-small">
                Logout
              </Link>
            </div>

          </div>
        </div>
      </header>

      {/* HERO SECTION */}
      <section className="hero">
        <div className="container">
          <div className="hero-content">
            <div className="hero-text">
              <h1>Learn Without Limits</h1>
              <p className="hero-description">
                Start, switch, or advance your career with 5,000+ courses, 
                Professional Certificates, and degrees from world-class universities and companies.
              </p>
              <div className="hero-actions">
                <Link to="/courselisting" className="btn btn-primary btn-large">
                  Explore Courses
                </Link>
                
              </div>
              <div className="hero-stats">
                <div className="stat">
                  <strong>50K+</strong>
                  <span>Students</span>
                </div>
                <div className="stat">
                  <strong>500+</strong>
                  <span>Courses</span>
                </div>
                <div className="stat">
                  <strong>100+</strong>
                  <span>Instructors</span>
                </div>
              </div>
            </div>
            <div className="hero-image">
              <div className="image-placeholder">
                🎓 Online Learning
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FEATURES */}
      <section className="features">
        <div className="container">
          <h2>Why Learn With Us?</h2>
          <div className="features-grid">
            {features.map((feature, index) => (
              <div key={index} className="feature-card">
                <div className="feature-icon">{feature.icon}</div>
                <h3>{feature.title}</h3>
                <p>{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* POPULAR COURSES */}
      <section className="popular-courses">
        <div className="container">
          <div className="section-header">
            <h2>Most Popular Courses</h2>
            <Link to="/courselisting" className="view-all">View All Courses →</Link>
          </div>
          <div className="courses-grid">
            {popularCourses.map(course => (
              <div key={course.id} className="course-card">
                <div className="course-image">
                  <div className="image-placeholder">Course Image</div>
                  <div className="course-level">{course.level}</div>
                </div>
                <div className="course-content">
                  <div className="course-meta">
                    <span className="rating">⭐ {course.rating}</span>
                    <span className="students">👥 {course.students.toLocaleString()}</span>
                    <span className="duration">⏱️ {course.duration}</span>
                  </div>
                  <h3>{course.title}</h3>
                  <p className="course-description">{course.description}</p>
                  <p className="instructor">By {course.instructor}</p>
                  <div className="course-footer">
                    <span className="price">{course.price}</span>
                    <Link to={'/enrollment'} className="btn btn-primary btn-small">
                      Enroll Now
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA SECTION */}
      <section className="cta">
        <div className="container">
          <div className="cta-content">
            <h2>Start Your Learning Journey Today</h2>
            <p>Join thousands of students already advancing their careers</p>
            <Link to="/register" className="btn btn-primary btn-large">
              Get Started Free
            </Link>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="footer">
        <div className="container">
          <div className="footer-content">
            <div className="footer-section">
              <h3>LearnHub</h3>
              <p>Empowering learners worldwide with quality education.</p>
            </div>
            <div className="footer-section">
              <h4>Platform</h4>
              <ul>
                <li><Link to="/courselisting">Browse Courses</Link></li>
                <li><Link to="/instructors">Instructors</Link></li>
                <li><Link to="/pricing">Pricing</Link></li>
                <li><Link to="/enterprise">For Business</Link></li>
              </ul>
            </div>
            <div className="footer-section">
              <h4>Support</h4>
              <ul>
                <li><Link to="/help">Help Center</Link></li>
                <li><Link to="/contact">Contact Us</Link></li>
                <li><Link to="/faq">FAQ</Link></li>
              </ul>
            </div>
            <div className="footer-section">
              <h4>Legal</h4>
              <ul>
                <li><Link to="/privacy">Privacy Policy</Link></li>
                <li><Link to="/terms">Terms of Service</Link></li>
                <li><Link to="/cookies">Cookie Policy</Link></li>
              </ul>
            </div>
          </div>
          <div className="footer-bottom">
            <p>&copy; 2025 LearnHub. All rights reserved.</p>
          </div>
        </div>
      </footer>

    </div>
  );
}          