import React, { useState } from "react";
import "../style/Admin.css";

export default function Admin() {
  const [students, setStudents] = useState([
    { id: 1, name: "John Doe", email: "john@example.com", course: "React Basics", enrollmentDate: "2024-01-15", status: "Active" },
    { id: 2, name: "Priya Sharma", email: "priya@example.com", course: "Python for Beginners", enrollmentDate: "2024-01-10", status: "Active" },
    { id: 3, name: "Mike Chen", email: "mike@example.com", course: "React Basics", enrollmentDate: "2024-01-20", status: "Inactive" },
  ]);

  const [courses, setCourses] = useState([
    { id: 1, name: "React Basics", description: "Learn React fundamentals", instructor: "John Smith", duration: "4 weeks", price: "$99", status: "Active" },
    { id: 2, name: "Python for Beginners", description: "Python programming basics", instructor: "Sarah Johnson", duration: "6 weeks", price: "$129", status: "Active" },
    { id: 3, name: "Advanced JavaScript", description: "Deep dive into JS", instructor: "Mike Brown", duration: "5 weeks", price: "$149", status: "Inactive" },
  ]);

  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCourse, setSelectedCourse] = useState("All");
  const [activeTab, setActiveTab] = useState("students");
  const [showCourseModal, setShowCourseModal] = useState(false);
  const [editingCourse, setEditingCourse] = useState(null);

  const [courseForm, setCourseForm] = useState({
    name: "",
    description: "",
    instructor: "",
    duration: "",
    price: "",
    status: "Active"
  });

  // Unique Course Filter for Students
  const availableCourses = ["All", ...new Set(students.map(s => s.course))];

  // Search + Filter Logic
  const filteredStudents = students.filter(student => {
    const matchesSearch =
      student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      student.email.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesCourse =
      selectedCourse === "All" || student.course === selectedCourse;

    return matchesSearch && matchesCourse;
  });

  // Delete Student
  const handleDeleteStudent = (id) => {
    if (window.confirm("Delete this student?")) {
      setStudents(prev => prev.filter(s => s.id !== id));
    }
  };

  // Delete Course
  const handleDeleteCourse = (id) => {
    if (window.confirm("Are you sure you want to delete this course?")) {
      setCourses(prev => prev.filter(c => c.id !== id));
    }
  };

  // Status Badge
  const getStatusBadge = (status) => {
    return status === "Active"
      ? "status-badge active"
      : "status-badge inactive";
  };

  // Add Course Button
  const handleAddCourse = () => {
    setEditingCourse(null);
    setCourseForm({
      name: "",
      description: "",
      instructor: "",
      duration: "",
      price: "",
      status: "Active"
    });
    setShowCourseModal(true);
  };

  // Edit Course Button
  const handleEditCourse = (course) => {
    setEditingCourse(course);
    setCourseForm(course);
    setShowCourseModal(true);
  };

  // Submit Add/Edit Course
  const handleCourseSubmit = (e) => {
    e.preventDefault();

    if (editingCourse) {
      // Update course
      setCourses(prev =>
        prev.map(c => (c.id === editingCourse.id ? { ...courseForm } : c))
      );
    } else {
      // Add new course
      const newCourse = {
        ...courseForm,
        id: courses.length > 0 ? Math.max(...courses.map(c => c.id)) + 1 : 1
      };
      setCourses(prev => [...prev, newCourse]);
    }

    setShowCourseModal(false);
    setEditingCourse(null);
  };

  // Form Input Change
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setCourseForm(prev => ({ ...prev, [name]: value }));
  };

  return (
    <div className="admin-dashboard">
      <header className="dashboard-header">
        <h1>Admin Dashboard</h1>
        <p>Manage Students & Courses</p>
      </header>

      {/* TAB SWITCHING */}
      <div className="tab-navigation">
        <button
          className={`tab-button ${activeTab === "students" ? "active" : ""}`}
          onClick={() => setActiveTab("students")}
        >
          Students Management
        </button>
        <button
          className={`tab-button ${activeTab === "courses" ? "active" : ""}`}
          onClick={() => setActiveTab("courses")}
        >
          Courses Management
        </button>
      </div>

      {/* STATS CARDS */}
      <div className="stats-container">
        <div className="stat-card">
          <h3>Total Students</h3>
          <p className="stat-number">{students.length}</p>
        </div>
        <div className="stat-card">
          <h3>Active Students</h3>
          <p className="stat-number">{students.filter(s => s.status === "Active").length}</p>
        </div>
        <div className="stat-card">
          <h3>Total Courses</h3>
          <p className="stat-number">{courses.length}</p>
        </div>
        <div className="stat-card">
          <h3>Active Courses</h3>
          <p className="stat-number">{courses.filter(c => c.status === "Active").length}</p>
        </div>
      </div>

      {/* STUDENTS TAB */}
      {activeTab === "students" && (
        <>
          <div className="filters-section">
            <input
              type="text"
              className="search-input"
              placeholder="Search by name or email..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />

            <select
              className="filter-select"
              value={selectedCourse}
              onChange={(e) => setSelectedCourse(e.target.value)}
            >
              {availableCourses.map(c => (
                <option key={c}>{c}</option>
              ))}
            </select>
          </div>

          <div className="students-section">
            <h2>Enrolled Students</h2>

            {filteredStudents.length === 0 ? (
              <p>No students found</p>
            ) : (
              <div className="students-table">
                <div className="table-header">
                  <div>Name</div>
                  <div>Course</div>
                  <div>Date</div>
                  <div>Status</div>
                  <div>Actions</div>
                </div>

                {filteredStudents.map(student => (
                  <div className="table-row" key={student.id}>
                    <div>
                      <strong>{student.name}</strong>
                      <p className="email">{student.email}</p>
                    </div>
                    <div>{student.course}</div>
                    <div>{student.enrollmentDate}</div>
                    <div>
                      <span className={getStatusBadge(student.status)}>
                        {student.status}
                      </span>
                    </div>
                    <div>
                      <button className="btn btn-delete" onClick={() => handleDeleteStudent(student.id)}>
                        Delete
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </>
      )}

      {/* COURSES TAB */}
      {activeTab === "courses" && (
        <div className="courses-section">
          <div className="section-header">
            <h2>Manage Courses</h2>
            <button className="btn btn-primary" onClick={handleAddCourse}>
              + Add Course
            </button>
          </div>

          <div className="courses-table">
            <div className="table-header">
              <div>Name</div>
              <div>Description</div>
              <div>Instructor</div>
              <div>Duration</div>
              <div>Price</div>
              <div>Status</div>
              <div>Actions</div>
            </div>

            {courses.map(course => (
              <div className="table-row" key={course.id}>
                <div>{course.name}</div>
                <div>{course.description}</div>
                <div>{course.instructor}</div>
                <div>{course.duration}</div>
                <div>{course.price}</div>
                <div>
                  <span className={getStatusBadge(course.status)}>{course.status}</span>
                </div>

                <div>
                  <button className="btn btn-edit" onClick={() => handleEditCourse(course)}>Edit</button>
                  <button className="btn btn-delete" onClick={() => handleDeleteCourse(course.id)}>Delete</button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* MODAL FOR ADD/EDIT COURSE */}
      {showCourseModal && (
        <div className="modal-overlay">
          <div className="modal-content">
            <h2>{editingCourse ? "Edit Course" : "Add Course"}</h2>

            <form onSubmit={handleCourseSubmit}>
              <input
                className="form-input"
                type="text"
                name="name"
                placeholder="Course Name"
                value={courseForm.name}
                onChange={handleInputChange}
                required
              />

              <textarea
                className="form-input"
                name="description"
                placeholder="Description"
                value={courseForm.description}
                onChange={handleInputChange}
                required
              />

              <input
                className="form-input"
                type="text"
                name="instructor"
                placeholder="Instructor"
                value={courseForm.instructor}
                onChange={handleInputChange}
                required
              />

              <input
                className="form-input"
                type="text"
                name="duration"
                placeholder="Duration"
                value={courseForm.duration}
                onChange={handleInputChange}
                required
              />

              <input
                className="form-input"
                type="text"
                name="price"
                placeholder="Price"
                value={courseForm.price}
                onChange={handleInputChange}
                required
              />

              <select
                className="form-input"
                name="status"
                value={courseForm.status}
                onChange={handleInputChange}
              >
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
              </select>

              <div className="modal-actions">
                <button type="button" className="btn btn-secondary" onClick={() => setShowCourseModal(false)}>
                  Cancel
                </button>
                <button type="submit" className="btn btn-primary">
                  {editingCourse ? "Update" : "Add"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
