import React, { useState, useEffect } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import "../style/Enrollment.css";

export default function Enroll() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    agreeToTerms: false
  });
  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const [course, setCourse] = useState(null);
  
  const onSubmitbutton=()=>{
    alert("successfully Enrolled.");
  }

  // Mock course data - in real app, this would come from an API
  const courses = {
    "1": { 
      id: 1, 
      title: "React for Beginners", 
      instructor: "Sarah Johnson", 
      price: "$89.99",
      duration: "6 weeks",
      level: "Beginner"
    },
    "2": { 
      id: 2, 
      title: "Python Full Stack Development", 
      instructor: "Mike Chen", 
      price: "$129.99",
      duration: "10 weeks",
      level: "Intermediate"
    },
    "3": { 
      id: 3, 
      title: "Complete Web Development Bootcamp", 
      instructor: "Emily Davis", 
      price: "$149.99",
      duration: "12 weeks",
      level: "Beginner"
    }
  };

  useEffect(() => {
    // Simulate API call to fetch course details
    const fetchCourse = async () => {
      setIsLoading(true);
      try {
        await new Promise(resolve => setTimeout(resolve, 500));
        const courseData = courses[id];
        if (courseData) {
          setCourse(courseData);
        } else {
          setErrors({ course: "Course not found" });
        }
      } catch {
        setErrors({ course: "Failed to load course details" });
      } finally {
        setIsLoading(false);
      }
    };

    if (id) {
      fetchCourse();
    }
  }, [id]);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
    
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: ''
      }));
    }
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData.firstName.trim()) {
      newErrors.firstName = "First name is required";
    }

    if (!formData.lastName.trim()) {
      newErrors.lastName = "Last name is required";
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!formData.email) {
      newErrors.email = "Email is required";
    } else if (!emailRegex.test(formData.email)) {
      newErrors.email = "Please enter a valid email address";
    }

    if (formData.phone && !/^\d{10}$/.test(formData.phone.replace(/\D/g, ''))) {
      newErrors.phone = "Please enter a valid 10-digit phone number";
    }

    if (!formData.agreeToTerms) {
      newErrors.agreeToTerms = "You must agree to the terms and conditions";
    }

    return newErrors;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    const formErrors = validateForm();
    if (Object.keys(formErrors).length > 0) {
      setErrors(formErrors);
      return;
    }

    setIsLoading(true);

    try {
      // Simulate API call for enrollment
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // In real app, this would be your enrollment endpoint
      const response = await fetch('/api/enrollments', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          courseId: id,
          ...formData,
          enrolledAt: new Date().toISOString()
        })
      });

      if (response.ok) {
        const enrollment = await response.json();
        console.log("Enrollment successful:", enrollment);
        
        // Redirect to success page or course dashboard
        navigate(`/enrollment-success/${enrollment.id}`);
      } else {
        throw new Error('Enrollment failed');
      }
    } catch (error) {
      console.error('Enrollment error:', error);
      setErrors({ submit: 'successfully Enrolled.' });
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading && !course) {
    return (
      <div className="enroll-container">
        <div className="loading">Loading course details...</div>
      </div>
    );
  }

  if (errors.course) {
    return (
      <div className="enroll-container">
        <div className="error-message">
          <h2>Course Not Found</h2>
          <p>{errors.course}</p>
          <Link to="/courses" className="btn btn-primary">Browse Courses</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="enroll-container">
      <div className="enroll-card">
        <div className="enroll-header">
          <h1>Enroll in Course</h1>
          {course && (
            <div className="course-summary">
              <h2>{course.title}</h2>
              <div className="course-details">
                <span>Instructor: {course.instructor}</span>
                <span>Level: {course.level}</span>
                <span>Duration: {course.duration}</span>
                <span className="price">{course.price}</span>
              </div>
            </div>
          )}
        </div>

        {errors.submit && (
          <div className="error-message global-error">
            {errors.submit}
          </div>
        )}

        <form onSubmit={handleSubmit} className="enroll-form">
          <div className="form-section">
            <h3>Personal Information</h3>
            <div className="form-row">
              <div className="form-group">
                <label htmlFor="firstName">First Name *</label>
                <input
                  id="firstName"
                  name="firstName"
                  type="text"
                  value={formData.firstName}
                  onChange={handleChange}
                  className={errors.firstName ? 'error' : ''}
                  placeholder="Enter your first name"
                  disabled={isLoading}
                />
                {errors.firstName && <span className="error-text">{errors.firstName}</span>}
              </div>

              <div className="form-group">
                <label htmlFor="lastName">Last Name *</label>
                <input
                  id="lastName"
                  name="lastName"
                  type="text"
                  value={formData.lastName}
                  onChange={handleChange}
                  className={errors.lastName ? 'error' : ''}
                  placeholder="Enter your last name"
                  disabled={isLoading}
                />
                {errors.lastName && <span className="error-text">{errors.lastName}</span>}
              </div>
            </div>

            <div className="form-group">
              <label htmlFor="email">Email Address *</label>
              <input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                className={errors.email ? 'error' : ''}
                placeholder="Enter your email address"
                disabled={isLoading}
              />
              {errors.email && <span className="error-text">{errors.email}</span>}
            </div>

            <div className="form-group">
              <label htmlFor="phone">Phone Number (Optional)</label>
              <input
                id="phone"
                name="phone"
                type="tel"
                value={formData.phone}
                onChange={handleChange}
                className={errors.phone ? 'error' : ''}
                placeholder="Enter your phone number"
                disabled={isLoading}
              />
              {errors.phone && <span className="error-text">{errors.phone}</span>}
            </div>
          </div>

          <div className="form-section">
            <h3>Enrollment Agreement</h3>
            <div className="form-group checkbox-group">
              <label className="checkbox-label">
                <input
                  name="agreeToTerms"
                  type="checkbox"
                  checked={formData.agreeToTerms}
                  onChange={handleChange}
                  className={errors.agreeToTerms ? 'error' : ''}
                  disabled={isLoading}
                />
                <span className="checkmark"></span>
                I agree to the <Link to="/terms" target="_blank">Terms of Service</Link> and 
                understand that I will be charged {course?.price} for this course.
              </label>
              {errors.agreeToTerms && <span className="error-text">{errors.agreeToTerms}</span>}
            </div>

            <div className="form-group checkbox-group">
              <label className="checkbox-label">
                <input
                  name="sendUpdates"
                  type="checkbox"
                  defaultChecked
                />
                <span className="checkmark"></span>
                Send me course updates and important announcements via email
              </label>
            </div>
          </div>

          <div className="enroll-actions">
            <button type="submit" onChange={onSubmitbutton}>SUBMIT</button>
            
            <Link to={'/Courselisting'} className="btn btn-outline">
              Back to Course Details
            </Link>
          </div>
        </form>

        <div className="enroll-footer">
          <div className="security-note">
            <span>🔒 Your information is secure and encrypted</span>
          </div>
          <div className="support-info">
            <p>Need help? <Link to="/contact">Contact support</Link> or call +1 (555) 123-4567</p>
          </div>
        </div>
      </div>
    </div>
  );
}