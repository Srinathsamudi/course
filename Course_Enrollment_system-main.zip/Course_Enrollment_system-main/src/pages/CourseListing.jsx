import React from "react";
import "../style/Course.css";
import { useNavigate } from "react-router-dom";
export default function Courses() {
  const courses = [
    { 
      id: 1, 
      title: "React Basics", 
      description: "Learn components, props, hooks.", 
      duration: "4 weeks",
      level: "Beginner",
      price: "$49.99"
    },
    { 
      id: 2, 
      title: "Python for Beginners", 
      description: "Start programming in Python.", 
      duration: "6 weeks",
      level: "Beginner",
      price: "$59.99"
    },
    { 
      id: 3, 
      title: "Web Development", 
      description: "HTML, CSS, JavaScript complete guide.", 
      duration: "8 weeks",
      level: "Intermediate",
      price: "$79.99"
    },
  ];

  const navigate = useNavigate();
  const handleEnroll = (courseId, courseTitle) => {
    // In a real app, this would integrate with your backend
    console.log(`Enrolling in course: ${courseTitle}`);
    // You could also use React Router for navigation
    navigate("/enrollment", { state: { courseId, courseTitle } });
    
    // Show confirmation (could be replaced with a modal)
    // alert(`Successfully enrolled in ${courseTitle}!`);
  };

  return (
    <div className="courses-container">
      <header className="courses-header">
        <h1 className="courses-title">Available Courses</h1>
        <p className="courses-subtitle">Expand your skills with our curated learning paths</p>
      </header>

      <div className="courses-grid">
        {courses.map((course) => (
          <div key={course.id} className="course-card">
            <div className="course-header">
              <h3 className="course-title">{course.title}</h3>
              <span className={`course-level course-level--${course.level.toLowerCase()}`}>
                {course.level}
              </span>
            </div>
            
            <p className="course-description">{course.description}</p>
            
            <div className="course-details">
              <div className="course-meta">
                <span className="course-duration">⏱️ {course.duration}</span>
                <span className="course-price">💵 {course.price}</span>
              </div>
            </div>

            <div className="course-actions">
              <button 
                className="btn btn--primary"
                onClick={() => handleEnroll(course.id, course.title)}
              >
                Enroll Now
              </button>
              <button className="btn btn--secondary">
                Learn More
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}